

     <!-- ==============================================
     Scripts
     =============================================== -->
	
     <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
     <script src="<?=$this->config->config['base_url']?>/backend/assets/js/bootstrap.min.js"></script>
     <script src="<?=$this->config->config['base_url']?>/backend/assets/js/pcoded.min.js"></script>
     <script src="<?=$this->config->config['base_url']?>/backend/assets/js/sweetalert.min.js"></script>
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
    <script type="text/javascript" src="<?=$this->config->config['base_url']?>/backend/assets/plugins/tempusdominus-bootstrap-4/tempusdominus-bootstrap-4.js"></script>
    <script type="text/javascript">
        $(function () {
            $('#datetimepicker1').datetimepicker({
                format: 'L',
				format: 'YYYY/MM/DD'
            });			
            $('#datetimepicker2').datetimepicker({
                format: 'L',
                format: 'YYYY/MM/DD'
            });	
        });
    </script>

           

          

         


    
 
</body></html>