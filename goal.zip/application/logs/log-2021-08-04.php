<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-04 13:40:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'evoting_platform' C:\xampp\htdocs\admin.evoting\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2021-08-04 13:40:45 --> Unable to connect to the database
ERROR - 2021-08-04 13:49:23 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:49:59 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 13:49:59 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 13:51:49 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:52:04 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:52:11 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:52:14 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:52:20 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:52:21 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:52:26 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:52:32 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 13:52:32 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 13:57:43 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:57:50 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 13:57:50 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 13:58:26 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:58:26 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 13:58:27 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 13:59:04 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:59:05 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 13:59:05 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 13:59:25 --> 404 Page Not Found: 
ERROR - 2021-08-04 13:59:29 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:00:28 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:00:30 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:00:32 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:00:59 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:01:03 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:01:29 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:02:25 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:03:20 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:04:29 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:04:44 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:06:14 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:08:59 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:10:06 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:10:33 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:11:22 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:11:37 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:12:26 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:12:55 --> 404 Page Not Found: 
ERROR - 2021-08-04 14:13:18 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 14:13:18 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 14:14:32 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 14:14:32 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 14:14:42 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 14:14:42 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 15:30:52 --> 404 Page Not Found: Backend/assets
ERROR - 2021-08-04 15:30:52 --> 404 Page Not Found: 
ERROR - 2021-08-04 15:30:52 --> 404 Page Not Found: Backend/assets
