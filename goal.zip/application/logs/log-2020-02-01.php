<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-01 00:00:02 --> 404 Page Not Found: 
ERROR - 2020-02-01 00:00:04 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:34:55 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:35:02 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:37:42 --> Query error: Unknown column 'post_id' in 'field list' - Invalid query: INSERT INTO `candidate` (`surname`, `othernames`, `membership_id`, `society`, `election_id`, `post_id`) VALUES ('oladele', 'Lily O', '203000', 'Lagos Girl', '3', '4')
ERROR - 2020-02-01 07:38:32 --> Severity: Notice --> Undefined index: position C:\xampp\htdocs\admin.evoting\application\views\admin\candidates.php 32
ERROR - 2020-02-01 07:38:32 --> Severity: Notice --> Undefined index: position C:\xampp\htdocs\admin.evoting\application\views\admin\candidates.php 32
ERROR - 2020-02-01 07:38:32 --> Severity: Notice --> Undefined index: position C:\xampp\htdocs\admin.evoting\application\views\admin\candidates.php 32
ERROR - 2020-02-01 07:38:33 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:39:19 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:39:53 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:39:57 --> Severity: Notice --> Undefined variable: candiate C:\xampp\htdocs\admin.evoting\application\views\admin\candidate.php 13
ERROR - 2020-02-01 07:39:57 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:41:22 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:42:42 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:43:11 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:44:11 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:44:38 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:44:40 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:44:43 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:44:49 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:46:36 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:54:34 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:56:59 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:57:42 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:57:45 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:57:49 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:57:52 --> 404 Page Not Found: 
ERROR - 2020-02-01 07:59:27 --> Severity: Warning --> move_uploaded_file(candidate_files/1580540367.png): failed to open stream: No such file or directory C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 104
ERROR - 2020-02-01 07:59:27 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\phpF411.tmp' to 'candidate_files/1580540367.png' C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 104
ERROR - 2020-02-01 07:59:28 --> 404 Page Not Found: 
ERROR - 2020-02-01 08:01:25 --> 404 Page Not Found: 
ERROR - 2020-02-01 08:03:48 --> 404 Page Not Found: 
ERROR - 2020-02-01 08:04:26 --> 404 Page Not Found: 
ERROR - 2020-02-01 08:05:17 --> 404 Page Not Found: 
ERROR - 2020-02-01 08:05:28 --> 404 Page Not Found: 
ERROR - 2020-02-01 08:05:28 --> 404 Page Not Found: 
ERROR - 2020-02-01 08:06:31 --> 404 Page Not Found: 
ERROR - 2020-02-01 09:56:54 --> 404 Page Not Found: 
ERROR - 2020-02-01 09:57:06 --> 404 Page Not Found: 
ERROR - 2020-02-01 09:57:06 --> 404 Page Not Found: 
ERROR - 2020-02-01 09:57:09 --> 404 Page Not Found: 
ERROR - 2020-02-01 09:58:09 --> Severity: Warning --> move_uploaded_file(candidate_files/4.png): failed to open stream: No such file or directory C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 88
ERROR - 2020-02-01 09:58:09 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php9605.tmp' to 'candidate_files/4.png' C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 88
ERROR - 2020-02-01 09:58:10 --> 404 Page Not Found: 
ERROR - 2020-02-01 09:58:10 --> 404 Page Not Found: 
ERROR - 2020-02-01 09:59:43 --> 404 Page Not Found: Candidate/edit
ERROR - 2020-02-01 09:59:43 --> 404 Page Not Found: 
ERROR - 2020-02-01 09:59:57 --> 404 Page Not Found: 
ERROR - 2020-02-01 09:59:57 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:00:02 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:00:04 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:00:39 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:01:26 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:06:27 --> Severity: error --> Exception: Call to undefined method CI_Loader::key_name_map() C:\xampp\htdocs\admin.evoting\application\views\admin\candidates.php 22
ERROR - 2020-02-01 10:06:27 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\admin.evoting\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\admin.evoting\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php 190
ERROR - 2020-02-01 10:08:00 --> Severity: error --> Exception: Call to undefined method CI_Loader::key_name_map() C:\xampp\htdocs\admin.evoting\application\views\admin\candidates.php 22
ERROR - 2020-02-01 10:08:00 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\admin.evoting\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\admin.evoting\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php 190
ERROR - 2020-02-01 10:08:33 --> Severity: error --> Exception: Call to undefined method CI_Loader::key_name_map() C:\xampp\htdocs\admin.evoting\application\views\admin\candidates.php 22
ERROR - 2020-02-01 10:08:33 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\admin.evoting\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\admin.evoting\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php 190
ERROR - 2020-02-01 10:09:11 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:09:37 --> Severity: error --> Exception: Call to undefined method CI_Loader::key_name_map() C:\xampp\htdocs\admin.evoting\application\views\admin\candidates.php 23
ERROR - 2020-02-01 10:09:37 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\admin.evoting\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\admin.evoting\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php 190
ERROR - 2020-02-01 10:11:14 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:12:12 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:16:15 --> Severity: Notice --> Undefined variable: electins C:\xampp\htdocs\admin.evoting\application\views\admin\candidates.php 35
ERROR - 2020-02-01 10:16:15 --> Severity: Notice --> Undefined variable: electins C:\xampp\htdocs\admin.evoting\application\views\admin\candidates.php 35
ERROR - 2020-02-01 10:16:15 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:16:28 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:18:06 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:18:45 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:19:22 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:19:49 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:20:15 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:21:30 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:21:56 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:55:01 --> Severity: Notice --> Undefined variable: elections C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 31
ERROR - 2020-02-01 10:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 31
ERROR - 2020-02-01 10:55:01 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 40
ERROR - 2020-02-01 10:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 40
ERROR - 2020-02-01 10:55:02 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:56:56 --> Severity: Notice --> Undefined variable: elections C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 31
ERROR - 2020-02-01 10:56:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 31
ERROR - 2020-02-01 10:56:56 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 40
ERROR - 2020-02-01 10:56:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 40
ERROR - 2020-02-01 10:56:56 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:57:17 --> Severity: Notice --> Undefined variable: elections C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 31
ERROR - 2020-02-01 10:57:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 31
ERROR - 2020-02-01 10:57:17 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 40
ERROR - 2020-02-01 10:57:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 40
ERROR - 2020-02-01 10:57:18 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:57:41 --> Severity: Notice --> Undefined variable: elections C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 31
ERROR - 2020-02-01 10:57:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 31
ERROR - 2020-02-01 10:57:41 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 40
ERROR - 2020-02-01 10:57:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\votingresults.php 40
ERROR - 2020-02-01 10:57:42 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:58:44 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:59:18 --> 404 Page Not Found: 
ERROR - 2020-02-01 10:59:27 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:00:39 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:01:38 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:01:49 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:02:51 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:03:30 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 11:03:30 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 11:05:24 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:06:46 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:07:25 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:34:55 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:34:59 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:35:01 --> Severity: Notice --> Undefined variable: election C:\xampp\htdocs\admin.evoting\application\views\admin\election.php 23
ERROR - 2020-02-01 11:35:01 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\admin.evoting\application\views\admin\election.php 29
ERROR - 2020-02-01 11:35:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\election.php 29
ERROR - 2020-02-01 11:35:02 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:35:22 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\admin.evoting\application\views\admin\election.php 29
ERROR - 2020-02-01 11:35:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\election.php 29
ERROR - 2020-02-01 11:35:23 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:35:30 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:35:32 --> Severity: Notice --> Undefined variable: posts C:\xampp\htdocs\admin.evoting\application\views\admin\election.php 29
ERROR - 2020-02-01 11:35:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admin.evoting\application\views\admin\election.php 29
ERROR - 2020-02-01 11:35:32 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:36:04 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:36:19 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:36:30 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:36:34 --> 404 Page Not Found: 
ERROR - 2020-02-01 11:36:37 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:53:13 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:53:18 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:53:21 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:53:27 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:53:31 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:53:33 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:53:38 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:54:11 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:55:05 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:57:36 --> 404 Page Not Found: Candidate/edit
ERROR - 2020-02-01 13:57:36 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:58:48 --> 404 Page Not Found: Candidate/edit
ERROR - 2020-02-01 13:58:48 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:58:56 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:58:59 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:59:07 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:59:10 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:59:35 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:59:38 --> 404 Page Not Found: 
ERROR - 2020-02-01 13:59:40 --> 404 Page Not Found: 
ERROR - 2020-02-01 18:49:58 --> 404 Page Not Found: 
ERROR - 2020-02-01 18:50:03 --> 404 Page Not Found: 
ERROR - 2020-02-01 18:50:08 --> 404 Page Not Found: 
ERROR - 2020-02-01 19:29:42 --> 404 Page Not Found: 
ERROR - 2020-02-01 19:29:45 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:12:39 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:12:56 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:12:58 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:14:05 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:14:05 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:14:05 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:14:10 --> Severity: Notice --> Undefined variable: candids C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 161
ERROR - 2020-02-01 20:17:39 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:17:39 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:17:39 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:17:42 --> Query error: Unknown column 'election_id' in 'where clause' - Invalid query: SELECT *
FROM `post`
WHERE `election_id` = ''
ERROR - 2020-02-01 20:17:46 --> Query error: Unknown column 'election_id' in 'where clause' - Invalid query: SELECT *
FROM `post`
WHERE `election_id` = '4'
ERROR - 2020-02-01 20:18:19 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 156
ERROR - 2020-02-01 20:23:08 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:23:08 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:23:08 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:23:13 --> Severity: Notice --> Undefined variable: break C:\xampp\htdocs\admin.evoting\application\views\templates\breakdown.php 30
ERROR - 2020-02-01 20:23:13 --> Severity: Notice --> Undefined variable: break C:\xampp\htdocs\admin.evoting\application\views\templates\breakdown.php 30
ERROR - 2020-02-01 20:24:22 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:26:18 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:26:54 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:29:25 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:33:22 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:34:41 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:39:47 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:46:22 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:47:01 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:48:17 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:49:26 --> Severity: Notice --> Undefined index: date_from C:\xampp\htdocs\admin.evoting\application\views\admin\elections.php 38
ERROR - 2020-02-01 20:49:26 --> Severity: Notice --> Undefined index: date_to C:\xampp\htdocs\admin.evoting\application\views\admin\elections.php 39
ERROR - 2020-02-01 20:49:26 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:49:54 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:50:53 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:50:56 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:51:12 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:51:32 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:51:33 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:52:07 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:52:12 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:52:22 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:53:19 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:54:11 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:54:20 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:54:20 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:54:42 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:56:06 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:57:06 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:57:06 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-01 20:57:32 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:58:35 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:58:54 --> 404 Page Not Found: 
ERROR - 2020-02-01 20:59:37 --> 404 Page Not Found: Logojpg/index
ERROR - 2020-02-01 20:59:39 --> 404 Page Not Found: Logojpg/index
ERROR - 2020-02-01 21:05:39 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:07:27 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:07:47 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:08:54 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:09:36 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:09:37 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:15:05 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:15:36 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:15:48 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:16:15 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:16:22 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:16:29 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:16:40 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:18:23 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\admin.evoting\application\views\admin\voter.php 38
ERROR - 2020-02-01 21:18:23 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ParseError given, called in C:\xampp\htdocs\admin.evoting\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\admin.evoting\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ParseError))
#1 [internal function]: _exception_handler(Object(ParseError))
#2 {main}
  thrown C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php 190
ERROR - 2020-02-01 21:19:03 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:19:10 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:19:12 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:19:20 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:19:21 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:20:31 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:20:35 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:20:44 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:21:50 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:22:00 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:23:02 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:24:09 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:24:27 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:26:42 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:26:50 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:26:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\admin.evoting\application\views\admin\election.php 41
ERROR - 2020-02-01 21:26:52 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ParseError given, called in C:\xampp\htdocs\admin.evoting\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\admin.evoting\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ParseError))
#1 [internal function]: _exception_handler(Object(ParseError))
#2 {main}
  thrown C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php 190
ERROR - 2020-02-01 21:27:14 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:27:24 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:28:04 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:28:10 --> 404 Page Not Found: 
ERROR - 2020-02-01 21:37:54 --> 404 Page Not Found: 
