<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-02 12:27:49 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-02 12:27:49 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-02 12:28:22 --> 404 Page Not Found: 
ERROR - 2020-02-02 12:29:03 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:20:10 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:26:19 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:33:23 --> Severity: Notice --> Undefined index: system_logo C:\xampp\htdocs\admin.evoting\application\views\admin\settings.php 39
ERROR - 2020-02-02 18:33:23 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:33:45 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:33:58 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:36:03 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:36:06 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:36:15 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:37:22 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:37:47 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:38:59 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:40:38 --> Severity: Warning --> move_uploaded_file(uploads/setting_files/.png): failed to open stream: No such file or directory C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 143
ERROR - 2020-02-02 18:40:38 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php5352.tmp' to 'uploads/setting_files/.png' C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 143
ERROR - 2020-02-02 18:40:38 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:40:48 --> Query error: Unknown column 'sitename' in 'field list' - Invalid query: UPDATE `setting` SET `sitename` = 'E-Voting', `title` = 'Electronic Voting System'
WHERE `setting_id` = '1'
ERROR - 2020-02-02 18:41:58 --> Query error: Unknown column 'sitename' in 'field list' - Invalid query: UPDATE `setting` SET `sitename` = 'E-Voting', `title` = 'Electronic Voting System'
WHERE `setting_id` = '1'
ERROR - 2020-02-02 18:42:01 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:42:01 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:42:03 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:42:03 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:42:11 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:42:11 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:42:22 --> Severity: Warning --> move_uploaded_file(uploads/setting_files/.png): failed to open stream: No such file or directory C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 143
ERROR - 2020-02-02 18:42:22 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\phpEB0A.tmp' to 'uploads/setting_files/.png' C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 143
ERROR - 2020-02-02 18:42:23 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:42:23 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:46:03 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:46:03 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:46:13 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:46:13 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:47:52 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:47:52 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:48:26 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:48:27 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:48:41 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:48:41 --> 404 Page Not Found: 
ERROR - 2020-02-02 18:49:21 --> 404 Page Not Found: 
ERROR - 2020-02-02 19:18:31 --> 404 Page Not Found: 
