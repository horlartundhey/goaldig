<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-16 10:56:36 --> 404 Page Not Found: 
