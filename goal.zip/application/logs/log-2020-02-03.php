<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-03 09:00:08 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:00:52 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:01:11 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:01:16 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:02:24 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:14:11 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:18:41 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:18:45 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:18:48 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:19:05 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:19:07 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:19:09 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:20:27 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:21:21 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:22:25 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:22:27 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:23:35 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:25:45 --> Severity: Notice --> Undefined variable: thiis C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 67
ERROR - 2020-02-03 09:25:45 --> Severity: error --> Exception: Call to a member function get() on null C:\xampp\htdocs\admin.evoting\application\controllers\Admin.php 67
ERROR - 2020-02-03 09:25:45 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\admin.evoting\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\admin.evoting\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\admin.evoting\system\core\Exceptions.php 190
ERROR - 2020-02-03 09:25:58 --> Query error: Table 'evoting_platform.settings' doesn't exist - Invalid query: SELECT *
FROM `settings`
ERROR - 2020-02-03 09:26:18 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:30:03 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:30:55 --> 404 Page Not Found: 
ERROR - 2020-02-03 09:31:09 --> 404 Page Not Found: Backend/assets
ERROR - 2020-02-03 09:31:09 --> 404 Page Not Found: Backend/assets
