<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-30 15:26:37 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:40:19 --> 404 Page Not Found: Vendors/fontawesome
ERROR - 2021-11-30 15:41:07 --> 404 Page Not Found: Vendors/fontawesome
ERROR - 2021-11-30 15:42:37 --> 404 Page Not Found: Assets/vendors
ERROR - 2021-11-30 15:43:12 --> 404 Page Not Found: Assets/vendors
ERROR - 2021-11-30 15:43:37 --> 404 Page Not Found: Assets/vendors
ERROR - 2021-11-30 15:44:10 --> 404 Page Not Found: Assets/vendors
ERROR - 2021-11-30 15:46:27 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:47:09 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:47:12 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:47:12 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:50:29 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:51:11 --> 404 Page Not Found: Assets/vendors
ERROR - 2021-11-30 15:51:11 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:51:11 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:51:57 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:51:58 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:52:00 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:52:01 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:52:05 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:52:06 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:52:28 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:52:28 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:52:28 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:52:30 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:52:30 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:52:31 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:52:36 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:52:36 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:52:36 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:52:43 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:52:45 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:53:06 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:53:48 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:53:51 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:54:30 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:55:00 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:55:00 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 15:55:04 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:55:10 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:55:18 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:55:22 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:55:25 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:55:40 --> 404 Page Not Found: 
ERROR - 2021-11-30 15:56:45 --> 404 Page Not Found: 
ERROR - 2021-11-30 16:50:49 --> 404 Page Not Found: 
ERROR - 2021-11-30 16:50:50 --> 404 Page Not Found: 
ERROR - 2021-11-30 16:50:50 --> 404 Page Not Found: Assets/vendors
ERROR - 2021-11-30 16:50:54 --> 404 Page Not Found: 
ERROR - 2021-11-30 16:50:57 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 16:50:57 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 16:51:09 --> 404 Page Not Found: 
ERROR - 2021-11-30 16:51:16 --> 404 Page Not Found: 
ERROR - 2021-11-30 16:51:20 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 16:51:20 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 16:52:34 --> 404 Page Not Found: 
ERROR - 2021-11-30 16:53:15 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 16:53:15 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 16:54:13 --> 404 Page Not Found: 
ERROR - 2021-11-30 17:04:31 --> 404 Page Not Found: 
ERROR - 2021-11-30 17:05:20 --> 404 Page Not Found: 
ERROR - 2021-11-30 17:05:22 --> 404 Page Not Found: 
ERROR - 2021-11-30 17:05:22 --> 404 Page Not Found: 
ERROR - 2021-11-30 17:34:05 --> 404 Page Not Found: 
ERROR - 2021-11-30 17:34:07 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 17:34:07 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 20:47:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'evoting_platform' C:\xampp\htdocs\goaldig-master\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2021-11-30 20:47:59 --> Unable to connect to the database
ERROR - 2021-11-30 20:51:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'evoting_platform' C:\xampp\htdocs\goaldig-master\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2021-11-30 20:51:49 --> Unable to connect to the database
ERROR - 2021-11-30 21:43:04 --> 404 Page Not Found: 
ERROR - 2021-11-30 21:43:10 --> 404 Page Not Found: Backend/assets
ERROR - 2021-11-30 21:43:10 --> 404 Page Not Found: Backend/assets
